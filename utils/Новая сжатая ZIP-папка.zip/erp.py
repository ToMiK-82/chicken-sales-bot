# utils/erp.py
import aiohttp
import asyncio
import logging
from typing import Tuple
from datetime import datetime

logger = logging.getLogger(__name__)

ODATA_URL = "http://194.28.90.23:9999/ka/odata/standard.odata/Document_РеализацияТоваровУслуг"

# ✅ ПРАВИЛЬНАЯ АУТЕНТИФИКАЦИЯ (Basic Auth)
USERNAME = "Python"
PASSWORD = "Serafima"

# ✅ ТОЧНЫЕ GUID ИЗ ТВОИХ ЗАПРОСОВ!
REFS = {
    "organization": "5f5fd793-c54b-11e8-9343-d8cb8ae28653",   # Управленческая организация
    "counterparty": "5f5fd917-c54b-11e8-9343-d8cb8ae28653",   # Розничный покупатель
    "department": "5a8290fd-ebbc-11e3-8846-bcaec598f3e4",     # ОП Полтавка
    "warehouse": "636323cd-192d-11e3-a1cc-c86000df0d7b",      # Склад Полтавка
    "price_type": "8be93d39-abf0-11ef-b8b3-d8bbc155dcfb",     # РозничнаяУП
    "agreement": "0f1c0de8-abf3-11ef-b8b3-d8bbc155dcfb",      # УП, оплата по факту
    "cash_desk": "815aa55b-ab14-11ef-b8b3-d8bbc155dcfb",      # КАССА Управленческая
    "issued_by": "f059adf7-ebd5-11e3-8846-bcaec598f3e4",      # Черный Василий Сергеевич
    "author": "faab8a40-ebe3-11e3-8846-bcaec598f3e4",         # Киселев Денис Геннадиевич
    "manager": "e8ba6564-7987-11ee-b85e-d8bbc155dcfb",        # Мирошниченко Андрей Владимирович
    "currency": "69244f56-c54b-11e8-9343-d8cb8ae28653",       # Рубль
    "vat_rate": "0e479bf5-6881-11ec-943a-d8cb8ae28653",       # Без НДС
    "nomenclature": {
        "Бройлер": "c456d676-fa4c-11ef-b8bf-d8bbc155dcfb",
        "Индюк": "c19fb679-62dc-11f0-b8d2-d8bbc155dcfb",
        "Мясо-яичная": "f89e6ef5-16ca-11f0-b8c2-d8bbc155dcfb",
        "Несушка": "de22c542-03dc-11f0-b8bf-d8bbc155dcfb",
        "Утка": "e5696dcb-19bc-11f0-b8c2-d8bbc155dcfb",
    }
}

async def send_order_to_1c(
    order_id: int,
    breed: str,
    quantity: int,
    price: float = 85.0
) -> Tuple[bool, str]:
    """
    Создаёт документ через OData с Basic Auth.
    """
    
    nomenclature_key = REFS["nomenclature"].get(breed)
    if not nomenclature_key:
        logger.error(f"❌ Неизвестная порода: {breed}")
        return False, f"Unknown breed: {breed}"

    now = datetime.now().isoformat()
    total_sum = round(quantity * price, 2)
    
    data = {
        "Организация_Key": REFS["organization"],
        "Контрагент_Key": REFS["counterparty"],
        "Подразделение_Key": REFS["department"],
        "Склад_Key": REFS["warehouse"],
        "ВидЦены_Key": REFS["price_type"],
        "Соглашение_Key": REFS["agreement"],
        "Касса_Key": REFS["cash_desk"],
        "Отпустил_Key": REFS["issued_by"],
        "Автор_Key": REFS["author"],
        "Менеджер_Key": REFS["manager"],
        "Валюта_Key": REFS["currency"],
        "Дата": now,
        "ЦенаВключаетНДС": False,
        "НалогообложениеНДС": "ПродажаОблагаетсяНДС",
        "ПорядокРасчетов": "ПоЗаказам",
        "ВариантОформленияПродажи": "РеализацияТоваровУслуг",
        "ХозяйственнаяОперация": "РеализацияКлиенту",
        "СпособДоставки": "Самовывоз",
        "Комментарий": f"Заказ из Telegram #{order_id}",
        "Проведен": False,
        "Товары": [
            {
                "Номенклатура_Key": nomenclature_key,
                "Количество": quantity,
                "Цена": price,
                "Сумма": total_sum,
                "ВидЦены_Key": REFS["price_type"],
                "Склад_Key": REFS["warehouse"],
                "СтавкаНДС_Key": REFS["vat_rate"],
                "СуммаНДС": 0
            }
        ]
    }

    headers = {
        "Content-Type": "application/json; charset=utf-8",
        "Accept": "application/json"
    }
    
    # ✅ Basic Auth
    auth = aiohttp.BasicAuth(USERNAME, PASSWORD)
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(
                ODATA_URL,
                json=data,
                headers=headers,
                auth=auth,
                timeout=30
            ) as resp:
                
                if resp.status == 201:
                    try:
                        result = await resp.json()
                        doc_number = result.get("Number", result.get("Номер", "неизвестно"))
                    except:
                        doc_number = "неизвестно"
                    logger.info(f"✅ Документ создан: №{doc_number}")
                    return True, f"Документ №{doc_number} создан"
                else:
                    text = await resp.text()
                    logger.error(f"❌ Ошибка {resp.status}: {text[:500]}")
                    return False, f"HTTP {resp.status}: {text[:200]}"
                    
    except asyncio.TimeoutError:
        logger.error("❌ Таймаут")
        return False, "Timeout"
    except Exception as e:
        logger.error(f"❌ Ошибка: {e}")
        return False, str(e)


async def test_odata_connection() -> Tuple[bool, str]:
    """Проверяет доступность OData-сервиса с Basic Auth."""
    test_url = "http://194.28.90.23:9999/ka/odata/standard.odata/$metadata"
    auth = aiohttp.BasicAuth(USERNAME, PASSWORD)
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(test_url, auth=auth, timeout=30) as resp:
                return resp.status == 200, "OK" if resp.status == 200 else f"HTTP {resp.status}"
    except Exception as e:
        return False, str(e)


async def send_to_1c(order_id: int, phone: str, breed: str, quantity: int, price: float = 85.0, action: str = "issue") -> Tuple[bool, str]:
    if action != "issue":
        return True, "Skipped"
    return await send_order_to_1c(order_id, breed, quantity, price)